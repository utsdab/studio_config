[![Build Status](https://dev.azure.com/shotgun-ecosystem/Toolkit/_apis/build/status/Configs/tk-config-default2?branchName=master)](https://dev.azure.com/shotgun-ecosystem/Toolkit/_build/latest?definitionId=49&branchName=master)

-------------------------------------------------------------------------
The Shotgun Pipeline Toolkit Default Configuration
-------------------------------------------------------------------------

Welcome to the Shotgun Pipeline Toolkit default configuration!

For more information, go to the following url:
https://support.shotgunsoftware.com/hc/en-us/articles/115000067493-Integrations-Admin-Guide

-------------------------------------------------------------------------
